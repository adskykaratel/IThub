from django.core.mail import send_mail
from post.models import Comment
from post.models import Post
def send_comment_notification(post_author,content,email_from,):
    # comment = Comment.objects.get(pk=comment_id)
    post_user = Post.objects.get(pk=post_author)
    subject = 'New Comment on Your Post'
    message = f'Hello {post_user.author.first_name},\n\n' \
              f'There is a new comment on your post "{post_user.title}".\n\n' \
              f'Comment: {content}\n\n' \
              f'Visit the post: {email_from}'
    from_email = f'{email_from}'
    recipient_list = [post_user.author.email]

    send_mail(subject, message, from_email, recipient_list)
