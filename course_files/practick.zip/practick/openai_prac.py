from openai import OpenAI
api_key = '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'
client = OpenAI(api_key=api_key)
# Замените 'your_api_key' на свой ключ API


def create_chat(messages):
    response = client.completions.create(model="gpt-3.5-turbo",
    messages=messages,
    temperature=1,
    max_tokens=150,
    top_p=1,
    frequency_penalty=0,
    presence_penalty=0)
    reply = response.choices[0].message.content.strip()
    return reply

print("Этот чат IT-internHUB, готов вам помочь")
chat_history = []

while True:
    # Запросите ввод пользователя
    user_input = input('Вы: ')

    # Добавьте сообщение пользователя к истории чата
    chat_history.append({"role": "user", "content": user_input})

    # Получите ответ от GPT-3 для чата
    response_from_chatbot = create_chat(chat_history)

    # Добавьте сообщение чатбота к истории чата
    chat_history.append({"role": "assistant", "content": response_from_chatbot})

    # Выведите ответ чатбота
    print(f'IT-internHUB: {response_from_chatbot}')


# Вопросы пользователя
user = [
    "Как создать цикл в Python?",
    "Как работает наследование в объектно-ориентированном программировании?",
    # Добавьте другие вопросы, которые могут интересовать пользователя
]

# Ответы чатбота
chatbot = [
    "В Python циклы создаются с использованием конструкции for или while.",
    "Наследование позволяет одному классу наследовать атрибуты и методы другого.",
    # Добавьте другие ответы, соответствующие вопросам пользователя
]

combined_chat_history = [{"role": "user", "content": u} for u in user] + [{"role": "assistant", "content": c} for c in chatbot]
