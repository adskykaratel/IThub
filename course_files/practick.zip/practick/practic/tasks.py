# post/tasks.py
from celery import shared_task
from django.core.mail import send_mail
from account.send_email import send_comment_notification

@shared_task
def send_comment_notification_tasks(email,):
    send_comment_notification(email,)